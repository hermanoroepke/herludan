import static org.junit.Assert.*;

import org.junit.Test;

public class SomaTest {

	/**
	 * Testa a soma com dois n�meros negativos.
	 */
	@Test
	public void test01() {
		int numero = Calculadora.soma(-1,-1);
		assertEquals(-2,numero);
	}
	
	/**
	 * Testa a soma com dois n�meros sendo um deles 0 e outro negativo.
	 */
	@Test
	public void test02() {
		int numero = Calculadora.soma(0,-1);
		assertEquals(-1,numero);
	}
	
	/**
	 * Testa a soma com dois n�meros positivos.
	 */
	@Test
	public void test03() {
		int numero = Calculadora.soma(2,3);
		assertEquals(5,numero);
	}
	
	/**
	 * Testa a soma com dois n�meros um negativo e um positivo.
	 */
	@Test
	public void test04() {
		int numero = Calculadora.soma(-1,1);
		assertEquals(0,numero);
	}
	
	/**
	 * Testa a soma com dois n�meros zeros.
	 */
	@Test
	public void test05() {
		int numero = Calculadora.soma(0,0);
		assertEquals(0,numero);
	}
	
	/**
	 * Testa a soma com zero e um n�mero positivo.
	 */
	@Test
	public void test06() {
		int numero = Calculadora.soma(0,1);
		assertEquals(1,numero);
	}
	
	
}
