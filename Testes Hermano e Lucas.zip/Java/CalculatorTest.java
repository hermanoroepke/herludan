import static org.junit.Assert.*;

import org.junit.Test;

public class CalculatorTest {
	Calculadora calculadora = new Calculadora();

	/**
	 * Calcula a express�o sem espa�os.
	 */
	@Test
	public void test01() {
		String expressao = "2+1-7";
		assertEquals(-4, calculadora.calculate(expressao));
	}

	/**
	 * Calcula a express�o com um espa�o.
	 */
	@Test
	public void test02() {
		String expressao = "2 +1-7";
		assertEquals(-4, calculadora.calculate(expressao));
	}

	/**
	 * Calcula a express�o com espacoes e algarismo com mais de uma casa
	 * decimal.
	 */
	@Test
	public void test03() {
		String expressao = "20 + 1000-  70+50";
		assertEquals(1000, calculadora.calculate(expressao));
	}

	/**
	 * Calcula express�o com espa�os depois dos operadores e depois do n�mero �
	 * espa�o vazio.
	 */
	@Test
	public void test04() {
		String expressao = "2 + 1- 7    ";
		assertEquals(-4, calculadora.calculate(expressao));
	}

	/**
	 * Calcula a express�o deixando espacos a cada passo.
	 */
	@Test
	public void test05() {
		String expressao = "2 + 1 ";
		assertEquals(-4, calculadora.calculate(expressao));
	}

	/**
	 * Calcula a opera��o com espa�os e sem espa�os
	 */
	@Test
	public void test06() {
		String expressao = "0 + 0-0+1-      1";
		assertEquals(-0, calculadora.calculate(expressao));
	}

	/**
	 * Calcula uma express�o gigante.
	 */
	@Test
	public void test08() {
		String expressao = "1+80000-80000+90000+    ";
		for (int i = 0; i < 10000; i++) {
			expressao += "3 + 5-                           8+";
		}
		expressao += "-90000";
		assertEquals(1, calculadora.calculate(expressao));
	}

}
